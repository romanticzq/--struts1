/**
 * 
 */

function judge() {
	if(document.getElementById("error").value==1) {
		alert("该用户名已存在！");
	}
	//得到用户名
	var name = document.getElementById("name").value;
	var length1 = name.length;
	if (length1 >20 || length1 <6) {
		alert("用户名长度必须在6-20个字符之间！");
		return false;
	}
	//得到密码
	var password1 = document.getElementById("password1").value;
	var length2 = password1.length;
	if (length2 >20 || length2 <6) {
		alert("密码长度必须在6-20个字符之间！");
		return false;
	}
	//得到重复密码
	var password2 = document.getElementById("password2").value;
	if (password2 != password1) {
		alert("密码与重复密码必须相同！");
		return false;
	}

	return true;
}
function onload1() {
	if(document.getElementById("error").value==1) {
		document.getElementById("error").value=0;
		alert("用户已存在！！！");
	}
}
