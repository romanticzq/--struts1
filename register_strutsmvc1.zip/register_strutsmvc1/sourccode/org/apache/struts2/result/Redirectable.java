package org.apache.struts2.result;

/**
 * Marking interface for results which perform browser redirection
 */
public interface Redirectable {

}
