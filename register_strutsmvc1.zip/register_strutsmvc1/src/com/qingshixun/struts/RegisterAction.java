package com.qingshixun.struts;

import java.sql.SQLException;

public class RegisterAction{

	//用户实体
	private User user;
	
	private UserService userService=new UserService();
	
	public void setUser(User user) {
		this.user = user;
	}
	
	public User getUser() {
		return user;
	}
	
	/**
	 * 进入注册页面
	 */
	public String register() {
		//在struts.xml文件中配置转向，跳转到：/WEB-INF/views/register。jsp
		return "success";
	}
	
	/**
	 * 保存页面
	 * @throws SQLException 
	 */
	public String save() throws SQLException {
		//接受前台传入的用户信息
		if(!userService.saveUser(user)) {
			return "false";
		}
		//保存完后跳转到注册结构页面
		//在Struts。xml文件中配置转向，跳转到：/WEB-INF/views/registerResult。jsp
		return "success";
	}
	
	
}
