package com.qingshixun.struts;

import java.sql.SQLException;

public class UserService {
	private UserDao userDao=new UserDao();
	
	/**
	 * 先判断再插入
	 * @param user
	 * @return
	 * @throws SQLException
	 */
	public boolean saveUser(User user) throws SQLException{
		if(userDao.getUserByUsername(user.getUsername())==null) {
			userDao.createUser(user);
			return true;
		}
		return false;
	}
}
