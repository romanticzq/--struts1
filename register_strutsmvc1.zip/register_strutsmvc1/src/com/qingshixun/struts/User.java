package com.qingshixun.struts;

import java.io.Serializable;

public class User {

	//用户名称
	private String username;
	
	//登录密码
	private String password;
	
	//重复密码
	private String repeatPassword;
	
	//电子邮箱
	private String email;
	
	//性别
	private String genter;
	
	//职业
	private String profession;
	
	//爱好
	private String hobby;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRepeatPassword() {
		return repeatPassword;
	}

	public void setRepeatPassword(String repeatPassword) {
		this.repeatPassword = repeatPassword;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGenter() {
		return genter;
	}

	public void setGenter(String genter) {
		this.genter = genter;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public String getHobby() {
		return hobby;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}

	public User(String username, String password, String repeatPassword, String email, String genter, String profession,
			String hobby) {
		super();
		this.username = username;
		this.password = password;
		this.repeatPassword = repeatPassword;
		this.email = email;
		this.genter = genter;
		this.profession = profession;
		this.hobby = hobby;
	}

	public User() {
		super();
	}
	
}
