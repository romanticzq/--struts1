package com.qingshixun.struts;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDao {
	private JDBCUtil jd= new JDBCUtil();
	
	/**
	 * 通过用户名查询信息
	 * @param username
	 * @return
	 * @throws SQLException
	 */
	public User getUserByUsername(String username) throws SQLException {

		Connection connection=jd.open();
		StringBuffer sql=new StringBuffer("select * from user where username=?");
		PreparedStatement ps=connection.prepareStatement(sql.toString());
		setParam(ps,username);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			//用不着取值，只需要返回一个user对象就行
//			String username1=rs.getString("username");
//			String password=rs.getString("password");
//			String repeatPassword=rs.getString("repeatPassword");
//			String email=rs.getString("email");
//			String genter=rs.getString("sex");
//			String profession=rs.getString("profession");
//			String hobby=rs.getString("hobby");
			jd.close(connection, ps, rs);
			User user=new User();
			return user;
		}
		return null;
	}
	
	/**
	 * 创建用户
	 * @param user
	 * @return
	 * @throws SQLException
	 */
	public int createUser(User user) throws SQLException {
		Connection connection=jd.open();
		StringBuffer sql=new StringBuffer("insert into user values(?,?,?,?,?,?,?)");
		PreparedStatement ps=connection.prepareStatement(sql.toString());
		setParam(ps,user.getUsername(),user.getPassword(),user.getRepeatPassword(),user.getEmail(),user.getGenter(),user.getProfession(),user.getHobby());
		int row=ps.executeUpdate();
		return row;
	}
	/**
	 * 设置参数
	 * @param ps
	 * @param objects
	 * @throws SQLException
	 */
	public void setParam(PreparedStatement ps, Object... objects) throws SQLException {
		for (int i = 0; i < objects.length; i++) {
			ps.setObject(i+1, objects[i]);
		}
	}
	
}
