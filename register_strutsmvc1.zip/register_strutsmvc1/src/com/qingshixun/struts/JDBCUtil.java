package com.qingshixun.struts;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCUtil {
	private static final String URL="jdbc:mysql://localhost:3306/myschool";
	private static final String USERNAME="root";
	private static final String PASSWORD="123456";
	private static final String DRIVER="com.mysql.jdbc.Driver";
	
	static {
		//加载数据库
		try {
			System.out.println("加载驱动");
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 构建数据库的连接
	 * @return
	 * @throws SQLException
	 */
	public Connection open() throws SQLException {
		System.out.println("连接数据库");
		return DriverManager.getConnection(URL, USERNAME, PASSWORD);
	}
	
	/**
	 * 释放资源
	 * @param connection
	 * @param ps
	 * @param rs
	 * @throws SQLException
	 */
	public void close(Connection connection,PreparedStatement ps,ResultSet rs) throws SQLException {
		if(rs!=null) {
			rs.close();
		}
		if(ps!=null) {
			ps.close();
		}
		if(connection!=null) {
			connection.close();
		}
		System.out.println("关闭数据库");
	}
}
